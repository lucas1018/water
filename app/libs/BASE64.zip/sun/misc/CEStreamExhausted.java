package sun.misc;

import java.io.IOException;

public class CEStreamExhausted extends IOException
{

}
